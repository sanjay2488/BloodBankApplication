package com.BloodDetails.Service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BloodDetailsServiceImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
