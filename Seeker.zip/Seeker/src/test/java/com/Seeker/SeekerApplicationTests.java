package com.Seeker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeekerApplicationTests {

	@Test
	void contextLoads() {
	}

}
